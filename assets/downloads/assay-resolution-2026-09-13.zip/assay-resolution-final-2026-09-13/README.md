# Assay resolution governs the transfer of molecular dependence

## Read

- `paper.pdf`: ten-page, two-column manuscript.
- `additional-file-1.pdf`: six-page supplement with proofs and analysis protocols.
- `submission.pdf`: fourteen-page, line-numbered submission layout.

The revision leads with adaptation-only prediction in 95 recipients. No scoring-cell
frequencies, thresholds, or pairings enter prediction. Retaining both assay-pattern
distributions reduces deviance by 16.6%, 29.2%, and 55.6% over individual frequencies
in Cambridge, Newcastle, and T-ALL, respectively. All nine comparisons with
individual frequencies, protein patterns, and independence have positive
Bonferroni percentile lower bounds. These are retrospective analyses, not a new
prospective confirmation. The conditional covariance experiments are reported
separately.

## Reproduce

From this folder, verify the distributed files:

```sh
shasum -a 256 -c SHA256SUMS
```

With Python 3.9 or newer and the dependencies in `analysis/requirements.txt`:

```sh
cd analysis
python3 reconstruct.py
python3 -m unittest -v test_reconstruct.py
python3 verify_reported_results.py
```

The artifact reconstructs predictions from derived assay distributions and fitted
source interactions, then recomputes the reported statistical summaries. It does
not include raw cell counts or repeat their acquisition and source-model fitting.
The analysis README describes the included arrays and verification scope.

To rebuild all three PDFs with TeX Live and latexmk:

```sh
cd source
latexmk -pdf -interaction=nonstopmode -halt-on-error reader.tex main.tex supplement.tex
```

## Submission Status

Scientific text, figures, supplement, and executable derived-data artifact are
included. The title pages remain blinded. Institutional addresses, corresponding
author designation, funding, competing interests, and contributions await author
confirmation. No new code license or public release identifier is asserted.
The paper and this bundle are distributed through the
[paper website](https://sushaan-k.github.io/coupling-fields-benchmark/).
